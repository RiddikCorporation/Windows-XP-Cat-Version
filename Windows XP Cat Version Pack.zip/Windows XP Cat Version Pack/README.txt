You need to restart to make the transformasion pack more stable after enabling it on your computer. To do that,run the RUNME AFTER DONE file after you're done transforming.

Sounds need to be named the same as default windows sounds in C:/WINDOWS/Media,drag them there and overwrite.
This way Windows XP will feel like a whole another OS.


Olive Green color scheme is recommended.

-TASKMAN,Riddik Corporation. 
Copyright 2021.

Any transformation packs made off this one without permission will be considered unofficial or fanmade by the developer.